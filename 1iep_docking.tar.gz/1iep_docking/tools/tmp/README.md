This folder contains temporary files of the tools like vf_continue_all.sh
