#!/usr/bin/env bash

# Copyright (C) 2019 Christoph Gorgulla
#
# This file is part of VirtualFlow.
#
# VirtualFlow is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# VirtualFlow is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with VirtualFlow.  If not, see <https://www.gnu.org/licenses/>.

# ----------------------------
#
# Usage: . prepare-todolists.sh jobline_no steps_per_job queues_per_step [quiet]
#
# Description: prepares the todolists for the queues. The tasks are taken from the central todo list ../../workflow/ligand-collections/todo/todo.all
#
# Option: quiet (optional)
#    Possible values:
#        quiet: No information is displayed on the screen.
#
# ---------------------------------------------------------------------------

# Idea: improve second backup mecha (copying back)


job_no_start="${1}"
job_no_end="${2}"
steps_per_job="${3}"  #always 1 currently
queues_per_step="${4}"
submit_mode=${5}
echo "job_no_start=$job_no_start"
((totaljobs=$job_no_end-$job_no_start+1))
echo "totaljobs=$totaljobs"

#src_file="todo.all"
src_file="../../workflow/ligand-collections/todo/todo.all"
mv $src_file ${src_file}.cloudam
touch $src_file
src_file=${src_file}.cloudam

#src_path="./"
src_path="../../workflow/ligand-collections/todo/"


totalsize=`cat $src_file |awk '{s+=$2} END {print s}'`
#totalsize=`cat ../../workflow/ligand-collections/todo/todo.all |awk '{s+=$2} END {print s}'`
echo "totalsize=$totalsize"
((ligands_per_job_avg=$totalsize/($totaljobs*$steps_per_job*$queues_per_step)))
ligands_per_job_avg_up=$(expr $ligands_per_job_avg*1.1 | bc)
ligands_per_job_avg_up=${ligands_per_job_avg_up%.*}
echo "ligands_per_job_avg=$ligands_per_job_avg"
echo "ligands_per_job_avg_up=$ligands_per_job_avg_up"

queue_no=""
for ((queue_no_1 = $job_no_start; queue_no_1 <= ${job_no_end}; queue_no_1++)); do
  echo "queue_no_1=$queue_no_1"
  for queue_no_2 in $(seq 1 ${steps_per_job}); do
    echo "queue_no_2=$queue_no_2"
      for queue_no_3 in $(seq 1 ${queues_per_step}); do
        echo "queue_no_3=$queue_no_3"
          queue_no="${queue_no_1}-${queue_no_2}-${queue_no_3}"
          touch ${src_path}${queue_no}
          echo "queue_no=$queue_no"
          currentsize=0
          while [[ $currentsize -lt $ligands_per_job_avg ]]; do
            row=`head -n 1 $src_file`
            count=`cat $src_file | wc -l`
             if [[ $count -eq 0 ]]; then
               continue 2
            fi
            rowcount=`echo $row|awk '{print $2}'`
            if [[ "$rowcount" -eq "" ]]; then
              rowcount=0
            fi
            oldsize=$currentsize
            currentsize=$(($currentsize + $rowcount))
            #if [ $oldsize -gt 0 ] && [ $currentsize -gt $ligands_per_job_avg_up ]; then
            #  continue 2
            #el
            if [ $currentsize -gt $ligands_per_job_avg ]; then
              echo $row >> ${src_path}${queue_no}
              sed -i '1d' $src_file
              continue 2
            else
              echo $row >> ${src_path}${queue_no}
              sed -i '1d' $src_file
            fi
          done
          #cat ${todo_new_temp_basename}_${queue_no} >> ../../workflow/ligand-collections/todo/${queue_no}
      done
  done
  if [[ "${submit_mode}" = "submit" ]]; then
     . submit.sh ../workflow/job-files/main/${queue_no_1}.job
  fi
done

for  i  in  `cat $src_file`; do
echo $i >> ${src_path}${queue_no}
done
cat /dev/null > $src_file
