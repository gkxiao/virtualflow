This folder normally contains all receptor structures.
These have to be added by the user during the setup of the docking scenarios.
Technically, the receptor structures can also be stored at other locations, but it recommended to use this folder which is shared by the varios docking scenarios.
