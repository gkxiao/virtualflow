This folder contains all the input-files which are used by the docking programs:
 * Docking program configuration files
 * Receptor structure files
 * Ligand input databases (can also be stored at another location, according to the setting in the control file)

The user has to create these contents, i.e. one folder for each docking scenario as described in the documentation.