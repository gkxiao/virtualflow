#!/bin/bash

DOCKERING_CONFIG_DIR=/public/software/.local/easybuild/software/virtualflow/examples/VFVS_GK

DOCKERING_WORKING_DIR=/home/cloudam/myfirsttest

mkdir -p $DOCKERING_WORKING_DIR

rm -rf $DOCKERING_WORKING_DIR/*

\cp -rf /public/software/.local/easybuild/software/virtualflow/vfvs/* $DOCKERING_WORKING_DIR

\cp -rf $DOCKERING_CONFIG_DIR/scenarios/* $DOCKERING_WORKING_DIR/input-files

\cp -rf $DOCKERING_CONFIG_DIR/receptors/* $DOCKERING_WORKING_DIR/input-files/receptors/

rm -rf $DOCKERING_WORKING_DIR/input-files/ligand-library

ln -sf  $DOCKERING_CONFIG_DIR/input-files/ligand-library $DOCKERING_WORKING_DIR/input-files


\cp -rf $DOCKERING_CONFIG_DIR/todo.all $DOCKERING_WORKING_DIR/tools/templates/


vf_param=`grep "=" $DOCKERING_CONFIG_DIR/vf.conf  |grep -v "#" `

for param in ${vf_param}; do

  IFS="="
  item=($param)

  str_num=`grep -ni ${item[0]} $DOCKERING_WORKING_DIR/tools/templates/all.ctrl|grep -v "#" | awk -F ':' '{print $1;}'`
  sed -i "${str_num}c ${param}" $DOCKERING_WORKING_DIR/tools/templates/all.ctrl
  if [ "${item[0]}" = "cpus_per_step" ]; then
        str_num=`grep -ni "queues_per_step" $DOCKERING_WORKING_DIR/tools/templates/all.ctrl|grep -v "#" | awk -F ':' '{print $1;}'`
        sed -i "${str_num}c queues_per_step=${item[1]}" $DOCKERING_WORKING_DIR/tools/templates/all.ctrl
  fi

done

cd $DOCKERING_WORKING_DIR/tools


NODE_NUMBER=3

./vf_prepare_folders.sh 

./vf_start_jobline.sh 1 $NODE_NUMBER templates/template1.slurm.sh submit 1
